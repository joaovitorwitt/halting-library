##################################################
# Imports
##################################################

from importlib import import_module
from os.path import dirname

##################################################
# Config File Implementation
##################################################
HALTING_ROOT = dirname(__file__)


def return_all_modules() -> list:
    pass